<!DOCTYPE HTML>
<html lang="zh-cn">
<head>
<meta charset="utf-8">
<title><?php echo $title; ?></title>


<link href="css/bootstrap.css" rel="stylesheet">
<link href="css/bootstrap-responsive.css" rel="stylesheet">
<link href="css/docs.css" rel="stylesheet">
<link href="css/prettify.css" rel="stylesheet">
<link href="css/nav.css" rel="stylesheet">
<link href="css/main.css" rel="stylesheet">


<script src="js/jquery.js"></script>
<script src="js/jquery-ui.js"></script>
<script src="js/bootstrap.js"></script>

<link rel="stylesheet" href="datepicker/css/jquery-ui.css" />
<script type="text/javascript" src="datepicker/js/jquery-ui-slide.min.js"></script>
<script type="text/javascript" src="datepicker/js/jquery-ui-timepicker-addon.js"></script>

<!--[if lt IE 9]>
<script src="js/html5shiv.js"></script>
<![endif]-->
<!--[if lte IE 8]>
<script src="js/ie8.js"></script>
<![endif]-->
<!--[if IE 9]>
<script src="js/ie9.js"></script>
<![endif]-->
</head>
<body>